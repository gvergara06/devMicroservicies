package ocm.gvergara.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestDockerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestDockerAppApplication.class, args);
	}
}
