package com.example.gvergara;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoLogApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoLogApplication.class, args);
	}
}
