package com.gvergara.zuul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZuulProyectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZuulProyectApplication.class, args);
	}
}
